module.exports = {
  tokens: "8126312159:AAHKdc0HyGmwPQc41Qthm6GGP_6jGKK49tE",  // Masukin Bot token kamu
  owners: "7909237750", // Masukin ID Telegram kamu
  port: "4178", // Masukin Port panel kamu 
  ipvps: "159.65.128.210" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};

/* WAJIB BACA !!!
 cari di index.js halaman 1995-1996 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/